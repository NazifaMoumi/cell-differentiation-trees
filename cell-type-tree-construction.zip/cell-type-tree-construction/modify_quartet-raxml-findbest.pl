#!/lusr/bin/perl -w

use strict;
use warnings;
use Getopt::Long;

#input: tree with both branch lengths and support values
#)sv:br

#output: see below

#make sure the raxml output does not contain the initial few lines with the taxa names. Remove all those lines.
sub badInput {
  my $message = "Usage: perl $0
	-i=<tree>
	-o=<output tree>
	-c=[or]to[or] <here o: ours and r: raxml>";
  print STDERR $message;
  die "\n";
}

GetOptions(
	"i=s"=>\my $tree,
	"o=s"=>\my $outtree,
	"c=s"=>\my $convert,
);

badInput() if not defined $tree;
badInput() if not defined $outtree;
badInput() if not defined $convert;

my %format_table = (
 "o" => "ours",
 "r" => "raxml",
);

my $informat, my $outformat;

if($convert =~ /(.)to(.)/) {
  $informat = $format_table{$1};
  $outformat = $format_table{$2};
}
else {
  die "can't parse file formats: $convert\n";
}

my $tree_contents = `cat $tree`;


my $tmp = "quart.tmp";
open(OUT, ">", $tmp) or die "can't open $tmp: $!";

#$tree_contents =~ s/\s/\n/g;

print OUT $tree_contents;
close(OUT);

open(OUT, ">", $outtree) or die "can't open $outtree: $!";

open(INFO, $tmp);		# Open the file
my @lines = <INFO>;		# Read it into an array
close(INFO);

print "\n I am here";

my $char = "a-zA-Z0-9.";
my $val = 0;   # to store the log-likelihood value
my $weight = 0;   # weight of the quartet
my $col_n = 4;  # log-likelihood is at 5-th column. so col_n = 4 as column number starts from 0.
my @col;
my $maxLQ;
my $counter = 0; # for each three lines (quartets), we will find the quartet with maximum log-likelihood
my $current_weight = 0;
if($outformat eq "ours") {
	foreach my $line (@lines){
	$counter = $counter + 1;
	$line =~ s/ /,/g;

#for finding log likelihood. First find all the values (numbers), and then find the last column which is supposed to be the log-likelihood
#=st
	$val = $line; 
	#$val =~ s/\s/\n/g;
        $val =~ s/:,/,/g;   # this and the next line ensure that all the numbers are separated by comma
        $val =~ s/\|,//g;
	@col=split(/,/,$val);  # split the string using comma as a REGEX
#	print "\n all columns @col";
#	foreach my $c (@col){
#	print "col: $c ";
#	}
	$val = $col[$col_n];
#	print "val: $val \n";

	# update val so that it indicates the relative frequencey of a quartet
	$weight = $val * -1;    # making the value positive
#	$weight = exp $val;
# end of value calculation
#=cut
	$line =~ s/,\|/\|/g;
	$line =~ s/\|,/\|/g; 
	print "\nline after comma: $line";
	$line =~ s/(^[$char])/\(\($1/g; 
	$line =~ s/\|/\),\(/g;
	$line =~ s/:,/\)\); /g;

# for updating the likelihood value
        $line =~ s/$val/$weight\n/g;

# we need to find the quartet with maximum log-likelihood on each four taxa. That means, for each three lines (quartets), we will find the quartet with maximum log-likelihood. 
	if ($counter == 1)
	{
		$maxLQ = $line;
		$current_weight = $weight;
	}
	else
	{
		if ($weight <= $current_weight)
		{	
			$maxLQ = $line;
			$current_weight = $weight;
		}
	}
	if ($counter == 3)
	{
		# to set the weight as one
		$maxLQ =~ s/$current_weight/1/g;  # comment out this line if you want acutal weight
		print OUT $maxLQ;  # this is the best quartet
		$counter = 0;  # reset the counter for next three lines
	}
   }
}

#ours to raxmal is not defined. so ignore the rest of the code
if($outformat eq "raxml") {
	foreach my $line (@lines){

#following is for ours to their

	$line =~ s/\(//g; 
	$line =~ s/\),/\|/g; 
	$line =~ s/\)//g; 
	$line =~ s/;\n/ /g; 
	print OUT "$line";  # ei \n ta kokhono lage kokhon lage na
	}
}

#print "\n here: $line";


#}
close(OUT);

`rm $tmp`;

print "output at $outtree\n";
print "done.\n";
